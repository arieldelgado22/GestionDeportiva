# Cómo probar el sistema

Agregue ejemplos de uso aquí con salida esperada.
