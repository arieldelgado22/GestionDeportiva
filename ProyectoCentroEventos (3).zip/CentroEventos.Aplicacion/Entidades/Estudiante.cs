
public class Estudiante : Persona
{
    public string NumeroAlumno { get; set; } = "";
    public string Carrera { get; set; } = "";
}
