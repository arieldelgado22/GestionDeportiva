
public class Docente : Persona
{
    public string Matricula { get; set; } = "";
    public int AnioIngreso { get; set; }
}
